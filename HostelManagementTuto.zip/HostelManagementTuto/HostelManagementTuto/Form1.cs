﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Media;
namespace HostelManagementTuto
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void bunifuThinButton21_Click(object sender, EventArgs e)
        {
           
            SoundPlayer splayer = new SoundPlayer();
            splayer.SoundLocation = @"C:\Users\User\source\repos\HostelManagementTuto\HostelManagementTuto\mixkit-negative-tone-interface-tap-2569.wav";
            splayer.Play();
            Rooms Myroom = new Rooms();
            Myroom.Show();
            this.Hide();
           


        }

        private void bunifuThinButton22_Click(object sender, EventArgs e)
        {
            SoundPlayer splayer = new SoundPlayer();
            splayer.SoundLocation = @"C:\Users\User\source\repos\HostelManagementTuto\HostelManagementTuto\mixkit-negative-tone-interface-tap-2569.wav";
            splayer.Play();
            Student Mystudent = new Student();
            Mystudent.Show();
            this.Hide();
        }

        private void bunifuThinButton23_Click(object sender, EventArgs e)
        {
            SoundPlayer splayer = new SoundPlayer();
            splayer.SoundLocation = @"C:\Users\User\source\repos\HostelManagementTuto\HostelManagementTuto\mixkit-negative-tone-interface-tap-2569.wav";
            splayer.Play();
            Employee Myemployee = new Employee();
            Myemployee.Show();
            this.Hide();
        }

        private void bunifuThinButton24_Click(object sender, EventArgs e)
        {
            SoundPlayer splayer = new SoundPlayer();
            splayer.SoundLocation = @"C:\Users\User\source\repos\HostelManagementTuto\HostelManagementTuto\mixkit-negative-tone-interface-tap-2569.wav";
            splayer.Play();
            Fees Myfees = new Fees();
            Myfees.Show();
            this.Hide();
        }
    }
}