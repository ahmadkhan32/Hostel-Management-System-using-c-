﻿using System;
using System.Data.SqlClient;

namespace HostelManagementTuto
{
    internal class cmdDataBase
    {
        internal static SqlDataReader ExecuteReader()
        {
            throw new NotImplementedException();
        }
    }
}