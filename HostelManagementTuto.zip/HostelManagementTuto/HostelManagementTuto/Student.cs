﻿using System;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Media;
namespace HostelManagementTuto
{
    public partial class Student : Form
    {
        public Student()
        {
            InitializeComponent();
        }
        SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\User\source\repos\HostelManagementTuto\HostelManagementTuto\HostelMgmt.mdf;Integrated Security=True;Connect Timeout=30");
        void FillStudentDGV()
        {
            Con.Open();
            string myquery = "Select * from Student_tbll";
            SqlDataAdapter da = new SqlDataAdapter(myquery, Con);
            SqlCommandBuilder builder = new SqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            StudentDGV.DataSource = ds.Tables[0];
            Con.Close();
        }
        void FillRoomCombobox()
        {
            Con.Open();
            string query = "select * from Room_tbl where RoomStatus='" + "Active" + "' and Booked='" + "Free" + "' ";
            SqlCommand cmd = new SqlCommand(query, Con);
            SqlDataReader rdr;
            rdr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Columns.Add("RoomNum", typeof(int));
            dt.Load(rdr);
            StudRoomCb.ValueMember = "RoomNum";
            StudRoomCb.DataSource = dt;
            Con.Close();

        }

        private void button4_Click(object sender, EventArgs e)
        {
            SoundPlayer splayer = new SoundPlayer();
            splayer.SoundLocation = @"C:\Users\User\source\repos\HostelManagementTuto\HostelManagementTuto\mixkit-negative-tone-interface-tap-2569.wav";
            splayer.Play();
            Form1 Home = new Form1();
            Home.Show();
            this.Hide();
        }

        private void label5_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        void updateBookedStatusOndelete()
        {
            Con.Open();
            string query = "update Room_tbl set Booked='" + "Free" + "' where RoomNum=" + StudRoomCb.SelectedValue.ToString() + "";
            SqlCommand cmd = new SqlCommand(query, Con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Room Succesfully Updated");
            Con.Close();
        }
        void updateBookedStatus()
        {
            Con.Open();
            string query = "update Room_tbl set Booked='" + "Busy" + "' where RoomNum=" + StudRoomCb.SelectedValue.ToString() + "";
            SqlCommand cmd = new SqlCommand(query, Con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Room Succesfully Updated");
            Con.Close();
        }


        private void button1_Click(object sender, EventArgs e)
        {
            SoundPlayer splayer = new SoundPlayer();
            splayer.SoundLocation = @"C:\Users\User\source\repos\HostelManagementTuto\HostelManagementTuto\mixkit-negative-tone-interface-tap-2569.wav";
            splayer.Play();
            if (StudUsn.Text == "" || StudName.Text == "" || AddressTb.Text == "" || CollegeTb.Text == "")
            {
                MessageBox.Show("No Empty Fill Accepted");
            }
            else
            {

                Con.Open();
                String query = " insert into Student_tbll values ('" + StudUsn.Text + "','" + StudName.Text + "','" + AddressTb.Text + "','" + CollegeTb.Text + "'," + StudRoomCb.SelectedValue.ToString() + ",'" + StudStatusCb.SelectedItem.ToString() + "')";
                SqlCommand cmd = new SqlCommand(query, Con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Student Successfully Added");
                Con.Close();
                FillStudentDGV();
                FillRoomCombobox();
            }


        }

        private void Student_Load_1(object sender, EventArgs e)
        {


        }

        private void View_Click(object sender, EventArgs e)
        {
            SoundPlayer splayer = new SoundPlayer();
            splayer.SoundLocation = @"C:\Users\User\source\repos\HostelManagementTuto\HostelManagementTuto\mixkit-negative-tone-interface-tap-2569.wav";
            splayer.Play();
            Con.Open();
            string query = "Select * from Student_tbll";
            SqlDataAdapter SDA = new SqlDataAdapter(query, Con);
            DataTable dt = new DataTable();
            SDA.Fill(dt);
            StudentDGV.DataSource = dt;
            Con.Close();
        }

        private void Student_Load(object sender, EventArgs e)
        {
            FillStudentDGV();
            FillRoomCombobox();
        }

        private void button3_Click(object sender, EventArgs e)
        {
           
            SoundPlayer splayer = new SoundPlayer();
            splayer.SoundLocation = @"C:\Users\User\source\repos\HostelManagementTuto\HostelManagementTuto\mixkit-negative-tone-interface-tap-2569.wav";
            splayer.Play();
            if (StudUsn.Text == "")
            {
                MessageBox.Show("Enter The Room Number");
            }
            else
            {
                Con.Open();
                String query = "delete from Student_tbll where StudUsn='" + StudUsn.Text + "'";
                SqlCommand cmd = new SqlCommand(query, Con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Room Successfully Deleted");
                Con.Close();
                updateBookedStatusOndelete();
                FillStudentDGV();
                FillRoomCombobox();
            }
        }

        private void StudentDGV_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {
            StudUsn.Text = StudentDGV.SelectedRows[0].Cells[0].Value.ToString();
            StudName.Text = StudentDGV.SelectedRows[0].Cells[1].Value.ToString();
            AddressTb.Text = StudentDGV.SelectedRows[0].Cells[2].Value.ToString();
            CollegeTb.Text = StudentDGV.SelectedRows[0].Cells[3].Value.ToString();
        }

    }
}


        
        
    

 


   


