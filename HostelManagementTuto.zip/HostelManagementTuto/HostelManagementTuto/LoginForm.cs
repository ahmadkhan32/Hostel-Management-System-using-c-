﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Media;

namespace HostelManagementTuto
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        private void btnlogin_Click(object sender, EventArgs e)
        {
            SoundPlayer splayer = new SoundPlayer();
            splayer.SoundLocation = @"C:\Users\User\source\repos\HostelManagementTuto\HostelManagementTuto\mixkit-negative-tone-interface-tap-2569.wav";
            splayer.Play();
            
            string user, pass;
            user = textBox1.Text;
            pass = textBox2.Text;

            if (user == "admin" && pass == "admin")
            {
                MessageBox.Show("succesfull");

                Form1 dashboard = new Form1();
                dashboard.Show();
            }
            else
            {
                MessageBox.Show("error");
            }
        }

        private void LoginForm_Load(object sender, EventArgs e)
        {

        }
    }
}
