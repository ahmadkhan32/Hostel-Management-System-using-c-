﻿using System;
using System.Windows.Forms;

namespace HostelManagementTuto
{
    partial class Student
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.StudUsn = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.StudName = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.AddressTb = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.CollegeTb = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.StudRoomCb = new System.Windows.Forms.ComboBox();
            this.StudStatusCb = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.StudentDGV = new System.Windows.Forms.DataGridView();
            this.View = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.StudentDGV)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.SandyBrown;
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1227, 62);
            this.panel1.TabIndex = 1;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.OrangeRed;
            this.label5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label5.Location = new System.Drawing.Point(1198, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(26, 25);
            this.label5.TabIndex = 8;
            this.label5.Text = "X";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label4.Location = new System.Drawing.Point(252, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(444, 48);
            this.label4.TabIndex = 0;
            this.label4.Text = "STUDENT INFORMATION";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 62);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1227, 22);
            this.panel2.TabIndex = 2;
            // 
            // StudUsn
            // 
            this.StudUsn.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.StudUsn.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.StudUsn.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.StudUsn.ForeColor = System.Drawing.Color.Black;
            this.StudUsn.HintForeColor = System.Drawing.Color.Empty;
            this.StudUsn.HintText = "";
            this.StudUsn.isPassword = false;
            this.StudUsn.LineFocusedColor = System.Drawing.Color.Blue;
            this.StudUsn.LineIdleColor = System.Drawing.Color.ForestGreen;
            this.StudUsn.LineMouseHoverColor = System.Drawing.Color.DeepPink;
            this.StudUsn.LineThickness = 3;
            this.StudUsn.Location = new System.Drawing.Point(2, 99);
            this.StudUsn.Margin = new System.Windows.Forms.Padding(6);
            this.StudUsn.Name = "StudUsn";
            this.StudUsn.Size = new System.Drawing.Size(252, 45);
            this.StudUsn.TabIndex = 4;
            this.StudUsn.Text = "Student Usn";
            this.StudUsn.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // StudName
            // 
            this.StudName.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.StudName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.StudName.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.StudName.ForeColor = System.Drawing.Color.Black;
            this.StudName.HintForeColor = System.Drawing.Color.Empty;
            this.StudName.HintText = "";
            this.StudName.isPassword = false;
            this.StudName.LineFocusedColor = System.Drawing.Color.Blue;
            this.StudName.LineIdleColor = System.Drawing.Color.ForestGreen;
            this.StudName.LineMouseHoverColor = System.Drawing.Color.DeepPink;
            this.StudName.LineThickness = 3;
            this.StudName.Location = new System.Drawing.Point(4, 156);
            this.StudName.Margin = new System.Windows.Forms.Padding(6);
            this.StudName.Name = "StudName";
            this.StudName.Size = new System.Drawing.Size(250, 45);
            this.StudName.TabIndex = 4;
            this.StudName.Text = "Stud Name";
            this.StudName.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // AddressTb
            // 
            this.AddressTb.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.AddressTb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.AddressTb.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.AddressTb.ForeColor = System.Drawing.Color.Black;
            this.AddressTb.HintForeColor = System.Drawing.Color.Empty;
            this.AddressTb.HintText = "";
            this.AddressTb.isPassword = false;
            this.AddressTb.LineFocusedColor = System.Drawing.Color.Blue;
            this.AddressTb.LineIdleColor = System.Drawing.Color.ForestGreen;
            this.AddressTb.LineMouseHoverColor = System.Drawing.Color.DeepPink;
            this.AddressTb.LineThickness = 3;
            this.AddressTb.Location = new System.Drawing.Point(0, 226);
            this.AddressTb.Margin = new System.Windows.Forms.Padding(6);
            this.AddressTb.Name = "AddressTb";
            this.AddressTb.Size = new System.Drawing.Size(254, 45);
            this.AddressTb.TabIndex = 4;
            this.AddressTb.Text = "Address";
            this.AddressTb.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // CollegeTb
            // 
            this.CollegeTb.BackColor = System.Drawing.Color.White;
            this.CollegeTb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.CollegeTb.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.CollegeTb.ForeColor = System.Drawing.Color.Black;
            this.CollegeTb.HintForeColor = System.Drawing.Color.Empty;
            this.CollegeTb.HintText = "";
            this.CollegeTb.isPassword = false;
            this.CollegeTb.LineFocusedColor = System.Drawing.Color.Blue;
            this.CollegeTb.LineIdleColor = System.Drawing.Color.ForestGreen;
            this.CollegeTb.LineMouseHoverColor = System.Drawing.Color.DeepPink;
            this.CollegeTb.LineThickness = 3;
            this.CollegeTb.Location = new System.Drawing.Point(4, 283);
            this.CollegeTb.Margin = new System.Windows.Forms.Padding(6);
            this.CollegeTb.Name = "CollegeTb";
            this.CollegeTb.Size = new System.Drawing.Size(252, 45);
            this.CollegeTb.TabIndex = 4;
            this.CollegeTb.Text = "College";
            this.CollegeTb.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(12, 409);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(156, 32);
            this.label3.TabIndex = 5;
            this.label3.Text = "ROOM NUM";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(12, 454);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(214, 32);
            this.label1.TabIndex = 5;
            this.label1.Text = "STUDENT STATUS";
            // 
            // StudRoomCb
            // 
            this.StudRoomCb.FormattingEnabled = true;
            this.StudRoomCb.Items.AddRange(new object[] {
            "Active",
            "NonActive"});
            this.StudRoomCb.Location = new System.Drawing.Point(174, 412);
            this.StudRoomCb.Name = "StudRoomCb";
            this.StudRoomCb.Size = new System.Drawing.Size(121, 28);
            this.StudRoomCb.TabIndex = 6;
            // 
            // StudStatusCb
            // 
            this.StudStatusCb.FormattingEnabled = true;
            this.StudStatusCb.Items.AddRange(new object[] {
            "Living",
            "Left"});
            this.StudStatusCb.Location = new System.Drawing.Point(243, 454);
            this.StudStatusCb.Name = "StudStatusCb";
            this.StudStatusCb.Size = new System.Drawing.Size(121, 28);
            this.StudStatusCb.TabIndex = 7;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(832, 88);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(206, 38);
            this.label6.TabIndex = 11;
            this.label6.Text = "STUDENT LIST";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.DarkGray;
            this.panel3.Controls.Add(this.label2);
            this.panel3.Location = new System.Drawing.Point(0, 645);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1227, 51);
            this.panel3.TabIndex = 12;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label2.Location = new System.Drawing.Point(306, 3);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(307, 48);
            this.label2.TabIndex = 0;
            this.label2.Text = "Develop By Khan";
            // 
            // button4
            // 
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.Color.Black;
            this.button4.Location = new System.Drawing.Point(162, 498);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(146, 45);
            this.button4.TabIndex = 13;
            this.button4.Text = "BACK";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button3
            // 
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.Black;
            this.button3.Location = new System.Drawing.Point(344, 498);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(147, 45);
            this.button3.TabIndex = 14;
            this.button3.Text = "DELETE";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button1
            // 
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.Black;
            this.button1.Location = new System.Drawing.Point(12, 498);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(106, 45);
            this.button1.TabIndex = 16;
            this.button1.Text = "ADD";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // StudentDGV
            // 
            this.StudentDGV.AllowUserToAddRows = false;
            this.StudentDGV.AllowUserToDeleteRows = false;
            this.StudentDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.StudentDGV.Location = new System.Drawing.Point(581, 128);
            this.StudentDGV.Name = "StudentDGV";
            this.StudentDGV.ReadOnly = true;
            this.StudentDGV.RowHeadersWidth = 62;
            this.StudentDGV.RowTemplate.Height = 28;
            this.StudentDGV.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.StudentDGV.Size = new System.Drawing.Size(634, 489);
            this.StudentDGV.TabIndex = 17;
            this.StudentDGV.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.StudentDGV_CellContentClick_1);
            // 
            // View
            // 
            this.View.BackColor = System.Drawing.Color.WhiteSmoke;
            this.View.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.View.Location = new System.Drawing.Point(174, 560);
            this.View.Name = "View";
            this.View.Size = new System.Drawing.Size(161, 57);
            this.View.TabIndex = 18;
            this.View.Text = "View";
            this.View.UseVisualStyleBackColor = false;
            this.View.Click += new System.EventHandler(this.View_Click);
            // 
            // Student
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1227, 698);
            this.Controls.Add(this.View);
            this.Controls.Add(this.StudentDGV);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.StudStatusCb);
            this.Controls.Add(this.StudRoomCb);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.CollegeTb);
            this.Controls.Add(this.AddressTb);
            this.Controls.Add(this.StudName);
            this.Controls.Add(this.StudUsn);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Student";
            this.Text = "Student";
            this.Load += new System.EventHandler(this.Student_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.StudentDGV)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private void StudentDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        

        }

        private static int GetRowIndex(DataGridViewCellEventArgs e)
        {
            return e.RowIndex;
        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel2;
        private Bunifu.Framework.UI.BunifuMaterialTextbox StudUsn;
        private Bunifu.Framework.UI.BunifuMaterialTextbox StudName;
        private Bunifu.Framework.UI.BunifuMaterialTextbox AddressTb;
        private Bunifu.Framework.UI.BunifuMaterialTextbox CollegeTb;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox StudRoomCb;
        private System.Windows.Forms.ComboBox StudStatusCb;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button1;
        private readonly EventHandler Student_Load1;
        private DataGridView StudentDGV;
        private Button View;
    }
}