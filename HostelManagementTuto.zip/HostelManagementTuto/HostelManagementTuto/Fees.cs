﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Media;

namespace HostelManagementTuto
{
    public partial class Fees : Form
    {
        SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\User\Documents\HostelMgmt.mdf;Integrated Security=True;Connect Timeout=30");
        private SqlDataReader rdr;

        public Fees()
        {
            InitializeComponent();
        }
        public void fillUsnCb ()
            {
            Con.Open();
            string query = "select StudUsn From Student_tbll";
            SqlCommand cmd = new SqlCommand(query, Con);
            rdr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Columns.Add("StudUsn", typeof(string));
            dt.Load(rdr);
            UsnCb.ValueMember = "StudUsn";
            UsnCb.DataSource = dt;
            Con.Close();
            }
        string studname, roomname;
        public void fecthdata()
        {
            Con.Open();
            string query = "select * from Student_tbll where StudUsn= '" + UsnCb.SelectedValue.ToString() + "'";
            SqlCommand cmd = new SqlCommand(query, Con);
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            foreach(DataRow dr in dt.Rows)
            {
                studname = dr["StudName"].ToString();
                roomname = dr["StudRoom"].ToString();
                StudentNameTb.Text = studname;
                RoomNumTb.Text = roomname;
            }
            Con.Close();
        }
        void FillFeesDGV()
        {
            Con.Open();
            string myquery = "Select * from Fees_tbl";
            SqlDataAdapter da = new SqlDataAdapter(myquery, Con);
            SqlCommandBuilder builder = new SqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            PaymentDGV.DataSource = ds.Tables[0];
            Con.Close();
        }

        private void label5_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            SoundPlayer splayer = new SoundPlayer();
            splayer.SoundLocation = @"C:\Users\User\source\repos\HostelManagementTuto\HostelManagementTuto\mixkit-negative-tone-interface-tap-2569.wav";
            splayer.Play();
            Form1 Home = new Form1();
            Home.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SoundPlayer splayer = new SoundPlayer();
            splayer.SoundLocation = @"C:\Users\User\source\repos\HostelManagementTuto\HostelManagementTuto\mixkit-negative-tone-interface-tap-2569.wav";
            splayer.Play();
            if (PaymentIdTb.Text == "" || StudentNameTb.Text == "" || UsnCb.Text == "" || AmountTb.Text ==  "")
            {
                MessageBox.Show("No Empty Fill Accepted");
            }
            else
            {
               
                string paymentperiode;
                paymentperiode = Periode.Value.Month.ToString() + Periode.Value.Year.ToString();
                Con.Open();
                SqlDataAdapter sda = new SqlDataAdapter("select COUNT(*) from Fees_tbl where StudentUSN = '" + UsnCb.SelectedValue.ToString() + "' and PaymntMonth = '" + paymentperiode.ToString()+ "'",Con);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                if (dt.Rows[0][0].ToString()=="1")
                {
                    MessageBox.Show("There is no Due for this Month");
                }
                
                //Con.Open();
                String query = "insert into Fees_tbl values('"+PaymentIdTb.Text+"','"+UsnCb.SelectedValue.ToString()+"','"+StudentNameTb.Text + "',"+RoomNumTb.Text + ",'" + paymentperiode + "',"+AmountTb.Text + ")";
                SqlCommand cmd = new SqlCommand(query, Con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Payment Successfully Added");
                Con.Close();
                FillFeesDGV();


                ///FillStudentDGV();
            }
           
        }
       

        private void UsnCb_SelectionChangeCommitted(object sender, EventArgs e)
        {
            fecthdata();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SoundPlayer splayer = new SoundPlayer();
            splayer.SoundLocation = @"C:\Users\User\source\repos\HostelManagementTuto\HostelManagementTuto\mixkit-negative-tone-interface-tap-2569.wav";
            splayer.Play();
            if (PaymentIdTb.Text == "")
            {
                MessageBox.Show("Enter The Payment Id");
            }
            else
            {
                Con.Open();
                String query = "delete from Fees_tbl where PaymentId="+PaymentIdTb.Text+"";
                SqlCommand cmd = new SqlCommand(query, Con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Payment Successfully Deleted");
                Con.Close();
                FillFeesDGV();
                //FillRoomDGV();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SoundPlayer splayer = new SoundPlayer();
            splayer.SoundLocation = @"C:\Users\User\source\repos\HostelManagementTuto\HostelManagementTuto\mixkit-negative-tone-interface-tap-2569.wav";
            splayer.Play();
            if (PaymentIdTb.Text == "")
            {
                MessageBox.Show("Enter The Payment Id");
            }
            else
            {
                string paymentperiode;
                paymentperiode = Periode.Value.Month.ToString() + Periode.Value.Year.ToString();
                Con.Open();
                String query = "update Fees_tbl set StudentUSN='"+UsnCb.SelectedValue.ToString()+"',Studentname='" + StudentNameTb.Text + "',StdRoom='" + RoomNumTb.Text + "',PaymntMonth='" +paymentperiode+ "',Amount=" + AmountTb.Text + " where PaymentId='"+PaymentIdTb.Text+"'";
                SqlCommand cmd = new SqlCommand(query, Con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Payment Successfully Updated");
                Con.Close();
                FillFeesDGV();

                
            }
        }

        private void PaymentDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            PaymentIdTb.Text = PaymentDGV.SelectedRows[0].Cells[0].Value.ToString();
            UsnCb.SelectedItem = PaymentDGV.SelectedRows[0].Cells[1].Value.ToString();
            StudentNameTb.Text = PaymentDGV.SelectedRows[0].Cells[2].Value.ToString();
            RoomNumTb.Text = PaymentDGV.SelectedRows[0].Cells[3].Value.ToString();
            //RoomNumTb.Text = PaymentDGV.SelectedRows[0].Cells[3].Value.ToString();
        }

        private void Fees_Load(object sender, EventArgs e)
        {
            fillUsnCb();
            FillFeesDGV();


        }
    }
}
